
%This file run test data in test folder using trained models  

leftimset= getData([], 'test','list1'); 
   ids = leftimset.ids;
   ROAD=[];
   color=[];
%    trainedModel1 = load('../data/train/iminfo/model1.mat');
   trainedModelCub2 = load('../data/train/iminfo/modelCub2.mat');
   
   
   for i = 1:size(ids,1)
       calib = getData(ids{i}, 'test', 'calib'); 
       leftimdata = getData(ids{i},'test', 'left');
       rightimdata = getData(ids{i},'test', 'right');
       leftim = rgb2gray(leftimdata.im);
       rightim = rgb2gray(rightimdata.im);
       disparity1 = disparity(leftim,rightim);
       fT = calib.f*calib.baseline;
       z = fT./disparity1;
       z(z>255)=255;
       Px = calib.K(1,3);
       Py = calib.K(2,3);
       
%   compute superpixels   
       [L,N] = superpixels(leftimdata.im,500,'Compactness',5);
       numRows = size(leftimdata.im,1);
       numCols = size(leftimdata.im,2);
%        figure;
       BW = boundarymask(L);
       imPlusBoundaries = imoverlay(leftimdata.im,BW,'cyan');

       %num of pixel in each superpixel
       pixelIdxList = label2idx(L);
       textureim = rangefilt(leftim);
       for eachsp = 1:N
            regpixel= pixelIdxList{eachsp};
            [y,x] = ind2sub(size(z), regpixel);
            sumX=0;
            sumY=0;
            meanX = mean(x);
            meanY= mean(y);
            meanZ = mean(z(regpixel));
            meanR= mean(leftimdata.im(regpixel));
            meanG= mean(mean(leftimdata.im(y,x,2))); 
            meanB= mean(mean(leftimdata.im(y,x,3)));
            meantexture = mean(textureim(regpixel));
            
            %put all features in one matrix where each column is a feature
            %and each row is one superpixel
            X = [meanX meanY meanZ single(meanR) single(meanB) single(meanG) single(meantexture)];
            
            % test data using different models 
            yfit = trainedModelCub2.trainedModelCub2.predictFcn(X);
%              yfit = trainedModelMediumGaus.predictFcn(X);
%              yfit = trainedModelFineGaus.predictFcn(X); 
%             yfit = trainedModelLin.predictFcn(X); 
%              yfit = trainedModelCoarseGaus.predictFcn(X); 



            redIdx = pixelIdxList{eachsp};
%             greenIdx = pixelIdxList{eachsp}+numRows*numCols;
%             blueIdx = pixelIdxList{eachsp}+2*numRows*numCols;
                        
%           highlighting road pixels
            if yfit == 1
                 leftimdata.im(redIdx)=0;
            end
          
%           compute camera coord xy for each pixel
            for each = 1:size(y,1)                
                 Xc = ((x(each,1)-Px) .*z(y(each,1),x(each,1)))/calib.f;
                 Yc = ((y(each,1)-Py) .*z(y(each,1),x(each,1)))./calib.f;
                  
                 %build array for pointcloud
                  if z(y(each,1),x(each,1)) >= 0
                      ROAD = [ROAD; Xc Yc z(y(each,1),x(each,1))];
                      color = [color;leftimdata.im(y(each,1),x(each,1),1) leftimdata.im(y(each,1),x(each,1),2) leftimdata.im(y(each,1),x(each,1),3)];
                  end
            end
                      
                    
       end
      ptcloud = pointCloud(ROAD,'Color',color);
%       f1=figure;
%       imshow(leftimdata.im);
%       dir = sprintf('../data/test/result/%d.jpg',i);
%       saveas(figure(f1),dir);
%       close all;
%        figure;
        pcshow(ptcloud,'MarkerSize',100);
       

    end
   
  
   
     


   
   
   
   