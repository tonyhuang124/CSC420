%load non-road pixel data
x0name=('../data/train/iminfo/x00.mat');
%load road pixel data
x1name=('../data/train/iminfo/x11.mat');

x0 = load(x0name);
x1 = load(x1name);
%randomly mixing the rows
x0rand = randperm(size(x0.X0,1));
x1rand = randperm(size(x1.X1,1));
%select the top 5000 in each set
x0new = x0.X0(x0rand(1:5000),:);
x1new = x1.X1(x1rand(1:5000),:);
% data ready to be trained in classifier
mix = [x0new;x1new];



    


