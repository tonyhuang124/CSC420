%this file compute the disparity and depth of all training image 
%then extracts all 7 features RGBXYZTexture into one matrix and making data
%ready to be trained
   leftimset= getData([], 'train','list1'); 
   gtimset = getData([],'train','listgt');
   ids = leftimset.ids;
   gtids = gtimset.ids;
   X0=[];
   X1=[];
   
   for i = 1:size(ids,1)
       calib = getData(ids{i}, 'train', 'calib'); 
       leftimdata = getData(ids{i},'train', 'left');
       rightimdata = getData(ids{i},'train', 'right');
       gtimdata = getData(gtids{i},'train','gt_left');
       leftim = rgb2gray(leftimdata.im);
       rightim = rgb2gray(rightimdata.im);
       gtim = gtimdata.im(:,:,3);
       disparity1 = disparity(leftim,rightim);
       fT = calib.f*calib.baseline;
       z = fT./disparity1;
       z(z>255)=255;
       Px = calib.K(1,3);
       Py = calib.K(2,3);
       
       %compute superpixels   
       [L,N] = superpixels(leftimdata.im,500,'Compactness',5);
       numRows = size(leftimdata.im,1);
       numCols = size(leftimdata.im,2);

       BW = boundarymask(L);
       imPlusBoundaries = imoverlay(leftimdata.im,BW,'cyan');

       
       %num of pixel in each superpixel
       pixelIdxList = label2idx(L);
       textureim = rangefilt(leftim);
       for eachsp = 1:N
            regpixel= pixelIdxList{eachsp};
            [y,x] = ind2sub(size(z), regpixel);
            sumX=0;
            sumY=0;

             for each = 1:size(y,1)
                  Xc = (x(each,1)-Px) *z(y(each,1),x(each,1))/calib.f;
%                 sumX = sumX+Xc;
                  Yc = (x(each,1)-Py) *z(y(each,1),x(each,1))/calib.f;
%                 sumY = sumY+Yc;  
             end
            meanX = mean(x);
            meanY= mean(y);
            meanZ = mean(z(regpixel));
            meanR= mean(leftimdata.im(regpixel));
            meanG= mean(mean(leftimdata.im(y,x,2))); 
            meanB= mean(mean(leftimdata.im(y,x,3)));
            meantexture = mean(textureim(regpixel));
            
            if mode(gtim(regpixel))== 255
                road = 1;
                line1 = [meanX meanY meanZ single(meanR) single(meanB) single(meanG) single(meantexture) road];
                X1 = [X1;line1];
                
            else 
                road = 0;
                line0 = [meanX meanY meanZ single(meanR) single(meanB) single(meanG) single(meantexture) road];
                X0 = [X0;line0];
            end
            
            
       end
   end
   
   

%       figure;
%       imagesc(z);
   
   x11name =sprintf('../data/train/iminfo/x11');
   save(x11name,'X1');
   x00name =sprintf('../data/train/iminfo/x00');
   save(x00name,'X0');
    
   
   
   
   