function [K, R, t] = KRt_from_P(P)

[K,R,t]=art(P);