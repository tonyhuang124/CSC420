globals;
data = getData([], 'train','list');
ids = data.ids;
width = [];
length = [];
HOG = [];
precent = 0;
width = [];
heigth = [];
for i = 178:size(ids,2)
    image = getData(ids{i}, 'train', 'left');
    im = image.im;
    %read label file
    fid = fopen(fullfile(DATA_TRAIN_DIR,'label', [ids{i} '.txt']), 'r+');
    label = textscan(fid, '%s %f %f %f %f %f %f %f %f %f %f %f %f %f %f');
    fclose(fid);
    index = find(strcmp(label{1}, 'Car'));

    if ~isempty(index)
        for box = 1:size(index,1)
            bs = [label{5}(index(box,1),1) label{6}(index(box,1),1) label{7}(index(box,1),1)-label{5}(index(box,1),1) label{8}(index(box,1),1)-label{6}(index(box,1),1)];
            width = [width bs(1,3)];
            heigth = [heigth bs(1,4)];
            %only select some of these image. 111 and 66 is the avg width
            %and heigth of all images
            if and(and(bs(1,3) >= 111*0.6,bs(1,3) <= 111*1.4),and(bs(1,4) >= 66*0.6,bs(1,4) <= 66*1.4))
                
                I2 = imcrop(im,bs);
                %105 and 60 is the avg of these crop image's width and

                %heigth
                I3 = imresize(I2,[105,60]);
                hog_feature = extractHOGFeatures(I3);
                HOG = [HOG; hog_feature label{15}(index(box,1),1)];
            end
        end
    end
    %printing the comple precentage
    if (i/size(ids,2))*100 - precent >= 1
        precent = (i/size(ids,2))*100;
        fprintf('%d%%\n',floor(precent));
    end
end
w = mode(width);
h = mode(heigth);
save('hog_features','HOG');





