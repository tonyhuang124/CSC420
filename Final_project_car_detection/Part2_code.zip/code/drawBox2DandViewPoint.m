function drawBox2DandViewPoint(im,model,bs,ds,Classes)
        imshow(im); hold on
        showboxesMy(im, reduceboxes(model, bs),'red');
        for car = 1:size(ds,1)
            viewpoint = viewpoint_prdict(Classes,im,ds(car,:));
            text(ds(car,1)+1,ds(car,2)+8,int2str(viewpoint),'Color','red','FontSize',18);
        end
        hold off;
end