addpath('dpm') ;
addpath('devkit') ;
globals;
if ~exist('Classes','var')
    %load classifier-----------------------------------------------------------
    Class_0 = load('Class_0_Classifier');
    Class_0 = Class_0.Class_0;
    Class_30 = load('Class_30_Classifier');
    Class_30 = Class_30.Class_30;
    Class_60 = load('Class_60_Classifier');
    Class_60 = Class_60.Class_60;
    Class_90 = load('Class_90_Classifier');
    Class_90 = Class_90.Class_90;
    Class_120 = load('Class_120_Classifier');
    Class_120 = Class_120.Class_120;
    Class_150 = load('Class_150_Classifier');
    Class_150 = Class_150.Class_150;
    Class_180 = load('Class_180_Classifier');
    Class_180 = Class_180.Class_180;
    Class_n30 = load('Class_n30_Classifier');
    Class_n30 = Class_n30.Class_n30;
    Class_n60 = load('Class_n60_Classifier');
    Class_n60 = Class_n60.Class_n60;
    Class_n90 = load('Class_n90_Classifier');
    Class_n90 = Class_n90.Class_n90;
    Class_n120 = load('Class_n120_Classifier');
    Class_n120 = Class_n120.Class_n120;
    Class_n150 = load('Class_n150_Classifier');
    Class_n150 = Class_n150.Class_n150;
    %--------------------------------------------------------------------------
    Classes = {};
    Classes{1} = Class_0;
    Classes{2} = Class_30;
    Classes{3} = Class_60;
    Classes{4} = Class_90;
    Classes{5} = Class_120;
    Classes{6} = Class_150;
    Classes{7} = Class_180;
    Classes{8} = Class_n30;
    Classes{9} = Class_n60;
    Classes{10} = Class_n90;
    Classes{11} = Class_n120;
    Classes{12} = Class_n150;
end



imdst = 'train';
data = getData([], [], 'detector-car');
model = data.model;
color = 'r';
list_data = getData([], imdst,'list');
ids = list_data.ids;


for i = 7444:7444
    imdata = getData(ids{i}, imdst, 'left');
    im = imdata.im;
    f = 1.5;
    imr = imresize(im,f); % if we resize, it works better for small objects
    % detect objects
    fprintf('running the detector, may take a few seconds...\n');
    tic;
    [ds, bs] = imgdetect(imr, model, -0.6);
    e = toc;
    fprintf('finished! (took: %0.4f seconds)\n', e);
    nms_thresh = 0.5;
    top = nms(ds, nms_thresh);
    ds(:, 1:end-2) = ds(:, 1:end-2)/f;
    bs(:, 1:end-2) = bs(:, 1:end-2)/f;
    if ~isempty(ds)
        ds = ds(top,:);
        for col = 1:size(ds,1)
             ds(col,3) = ds(col,3)-ds(col,1);
             ds(col,4) = ds(col,4)-ds(col,2);
        end
        ds =ds(:,1:4);
        
        
        
%------------------------------Draw 2D box for each car--------------------      

        %drawBox2DandViewPoint(im,model,bs(top,:),ds,Classes);

%------------------------------Draw 3D box for each car--------------------
        drawBox3D(ids{i},imdst,ds,Classes);

    end
end

