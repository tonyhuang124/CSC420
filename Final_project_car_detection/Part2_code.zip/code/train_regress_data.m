data  = getData([], [], 'HOG');
train_precent = 0.8;
test_precent = 1 - train_precent;
index_of_last = size(data.hog,2);




for labels = 1:size(data.hog,1)
    if data.hog(labels,index_of_last) + (pi/2.0) > pi
        data.hog(labels,index_of_last) = ((data.hog(labels,index_of_last) + (pi/2.0) - pi)/pi)*180;
    else
        data.hog(labels,index_of_last) = ((data.hog(labels,index_of_last) + (pi/2.0))/pi)*180;
    end
end
train_idn =  floor(size(data.hog,1)*train_precent);

train_data = data.hog(1:train_idn ,:);
% train_label = data.hog(1:train_idn ,index_of_last);
test_data = data.hog(train_idn:size(data.hog,1) ,:);
% test_label = data.hog(train_idn:size(data.hog,1) ,index_of_last);

% mdl = fitrsvm(train_data,train_label);


