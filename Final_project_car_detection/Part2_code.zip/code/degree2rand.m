function rand = degree2rand(degree)

semi = (degree/180.0)*pi;
if and(abs(degree) >= 90,abs(degree) < 180)
    rand = semi + (pi/2);
else
    rand = semi - (pi/2);
end