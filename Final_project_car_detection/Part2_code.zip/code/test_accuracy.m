correct = 0;
correct1 = 0;
precent = 0;






%% Convert -pi to pi TO -180 to 180
data  = getData([], [], 'HOG');
train_precent = 0.8;
test_precent = 1 - train_precent;
index_of_last = size(data.hog,2);
%mode 1 for 12 binary classifiers and mode 0 for muti classifier
mode = 0;



for labels = 1:size(data.hog,1)
    if data.hog(labels,index_of_last) + (pi/2.0) > pi
        data.hog(labels,index_of_last) = floor((((data.hog(labels,index_of_last) + (pi/2.0) - pi)/pi)*180)/30)*30;
        if data.hog(labels,index_of_last) > 0
            data.hog(labels,index_of_last) = data.hog(labels,index_of_last) + 30;
        end
    else
        data.hog(labels,index_of_last) = floor((((data.hog(labels,index_of_last) + (pi/2.0))/pi)*180)/30)*30;
        if data.hog(labels,index_of_last) > 0
            data.hog(labels,index_of_last) = data.hog(labels,index_of_last) + 30;
        end
    end
end


%% muti-classifier data
train_idn =  floor(size(data.hog,1)*train_precent);
train_data = data.hog(1:train_idn ,1:index_of_last);
test_data = data.hog(train_idn:size(data.hog,1) ,1:index_of_last);




    %% binary-classifier data
    %class = {0,30,60,90,120,150,180,-30,-60,-90,-120,-150}

    %0 and non0 data
    train_data_0 = train_data;
    test_data_0 = test_data;
    for i = 1:size(train_data,1)
        if train_data_0(i,index_of_last) == 0
            train_data_0(i,index_of_last) = 1;
        else
            train_data_0(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_0(i,index_of_last) == 0
            test_data_0(i,index_of_last) = 1;
        else
            test_data_0(i,index_of_last) = 0;
        end
    end

    %30 and non30 data
    train_data_30 = train_data;
    test_data_30 = test_data;
    for i = 1:size(train_data,1)
        if train_data_30(i,index_of_last) == 30
            train_data_30(i,index_of_last) = 1;
        else
            train_data_30(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_30(i,index_of_last) == 30
            test_data_30(i,index_of_last) = 1;
        else
            test_data_30(i,index_of_last) = 0;
        end
    end

    %60 and non60 data
    train_data_60 = train_data;
    test_data_60 = test_data;
    for i = 1:size(train_data,1)
        if train_data_60(i,index_of_last) == 60
            train_data_60(i,index_of_last) = 1;
        else
            train_data_60(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_60(i,index_of_last) == 60
            test_data_60(i,index_of_last) = 1;
        else
            test_data_60(i,index_of_last) = 0;
        end
    end

    %90 and non90 data
    train_data_90 = train_data;
    test_data_90 = test_data;
    for i = 1:size(train_data,1)
        if train_data_90(i,index_of_last) == 90
            train_data_90(i,index_of_last) = 1;
        else
            train_data_90(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_90(i,index_of_last) == 90
            test_data_90(i,index_of_last) = 1;
        else
            test_data_90(i,index_of_last) = 0;
        end
    end

    %120 and non120 data
    train_data_120 = train_data;
    test_data_120 = test_data;
    for i = 1:size(train_data,1)
        if train_data_120(i,index_of_last) == 120
            train_data_120(i,index_of_last) = 1;
        else
            train_data_120(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_120(i,index_of_last) == 120
            test_data_120(i,index_of_last) = 1;
        else
            test_data_120(i,index_of_last) = 0;
        end
    end

    %150 and non150 data
    train_data_150 = train_data;
    test_data_150 = test_data;
    for i = 1:size(train_data,1)
        if train_data_150(i,index_of_last) == 150
            train_data_150(i,index_of_last) = 1;
        else
            train_data_150(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_150(i,index_of_last) == 150
            test_data_150(i,index_of_last) = 1;
        else
            test_data_150(i,index_of_last) = 0;
        end
    end


    %180 and non180 data
    train_data_180 = train_data;
    test_data_180 = test_data;
    for i = 1:size(train_data,1)
        if train_data_180(i,index_of_last) == 180
            train_data_180(i,index_of_last) = 1;
        else
            train_data_180(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_180(i,index_of_last) == 180
            test_data_180(i,index_of_last) = 1;
        else
            test_data_180(i,index_of_last) = 0;
        end
    end


    %-30 and non-30 data
    train_data_n30 = train_data;
    test_data_n30 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n30(i,index_of_last) == -30
            train_data_n30(i,index_of_last) = 1;
        else
            train_data_n30(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n30(i,index_of_last) == -30
            test_data_n30(i,index_of_last) = 1;
        else
            test_data_n30(i,index_of_last) = 0;
        end
    end

    %-60 and non-60 data
    train_data_n60 = train_data;
    test_data_n60 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n60(i,index_of_last) == -60
            train_data_n60(i,index_of_last) = 1;
        else
            train_data_n60(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n60(i,index_of_last) == -60
            test_data_n60(i,index_of_last) = 1;
        else
            test_data_n60(i,index_of_last) = 0;
        end
    end

    %-90 and non-90 data
    train_data_n90 = train_data;
    test_data_n90 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n90(i,index_of_last) == -90
            train_data_n90(i,index_of_last) = 1;
        else
            train_data_n90(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n90(i,index_of_last) == -90
            test_data_n90(i,index_of_last) = 1;
        else
            test_data_n90(i,index_of_last) = 0;
        end
    end

    %120 and non-120 data
    train_data_n120 = train_data;
    test_data_n120 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n120(i,index_of_last) == -120
            train_data_n120(i,index_of_last) = 1;
        else
            train_data_n120(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n120(i,index_of_last) == -120
            test_data_n120(i,index_of_last) = 1;
        else
            test_data_n120(i,index_of_last) = 0;
        end
    end

    %150 and non-150 data
    train_data_n150 = train_data;
    test_data_n150 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n150(i,index_of_last) == -150
            train_data_n150(i,index_of_last) = 1;
        else
            train_data_n150(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n150(i,index_of_last) == -150
            test_data_n150(i,index_of_last) = 1;
        else
            test_data_n150(i,index_of_last) = 0;
        end
    end
% classifiers = load('12_classifiers');
% Class_0 = classifiers.Class_0;
% Class_30 = classifiers.Class_30;
% Class_60=classifiers.Class_60;
% Class_90=classifiers.Class_90;
% Class_120=classifiers.Class_120;
% Class_150=classifiers.Class_150;
% Class_180=classifiers.Class_180;
% Class_n30=classifiers.Class_n30;
% Class_n60=classifiers.Class_n60;
% Class_n90=classifiers.Class_n90;
% Class_n120=classifiers.Class_n120;
% Class_n150=classifiers.Class_n150;
% for i = 1:size(test_data,1) 
%    label = predict(SVM.ClassificationSVM,test_data(i,1:2592));
%    if label == test_data(i,2593)
%        correct = correct + 1;
%    end
%    if (i/size(test_data,1))*100 - precent >= 1
%     precent = (i/size(test_data,1))*100;
%     fprintf('%d%%\n',floor(precent));
%    end
% end
% fprintf('-------------------------------------\n');
% fprintf('%d%%\n',correct/size(test_data,1)*100);



for i = 1:size(test_data,1)
        class=[];
        [YHat1,score1] = predict(Class_0,test_data(i,1:2592));
        class = [class;0 score1(1,2)];
        [YHat2,score2] = predict(Class_30,test_data(i,1:2592));
        class = [class;30 score2(1,2)];
        [YHat3,score3] = predict(Class_60,test_data(i,1:2592));
        class = [class;60 score3(1,2)];
        [YHat4,score4] = predict(Class_90,test_data(i,1:2592));
        class = [class;90 score4(1,2)];
        [YHat5,score5] = predict(Class_120,test_data(i,1:2592));
        class = [class;120 score5(1,2)];
        [YHat6,score6] = predict(Class_150,test_data(i,1:2592));
        class = [class;150 score6(1,2)];
        [YHat7,score7] = predict(Class_180,test_data(i,1:2592));
        class = [class;180 score7(1,2)];
        [YHat8,score8] = predict(Class_n30,test_data(i,1:2592));
        class = [class;-30 score8(1,2)];
        [YHat9,score9] = predict(Class_n60,test_data(i,1:2592));
        class = [class;-60 score9(1,2)];
        [YHat10,score10] = predict(Class_n90,test_data(i,1:2592));
        class = [class;-90 score10(1,2)];
        [YHat11,score11] = predict(Class_n120,test_data(i,1:2592));
        class = [class;-120 score11(1,2)];
        [YHat12,score12] = predict(Class_n150,test_data(i,1:2592));
        class = [class;-150 score12(1,2)];
        [value,idx] = max(class(:,2));
        label = class(idx,1);
        label1 = predict(Class_muti,test_data(i,1:2592));
        
        if label1 == test_data(i,2593)
           correct1 = correct1 + 1;
        end
        
        if label == test_data(i,2593)
           correct = correct + 1;
        end
        if (i/size(test_data,1))*100 - precent >= 1
           precent = (i/size(test_data,1))*100;
           fprintf('%d%%\n',floor(precent));
        end  
end
rate_12 = correct/size(test_data,1)*100;
rate_muti = correct1/size(test_data,1)*100;

y = [rate_12 rate_muti];



% for i = 1:size(train_data,1)
%         class=[];
%         [YHat1,score1] = predict(Class_0,train_data(i,1:2592));
%         class = [class;0 score1(1,2)];
%         [YHat2,score2] = predict(Class_30,train_data(i,1:2592));
%         class = [class;30 score2(1,2)];
%         [YHat3,score3] = predict(Class_60,train_data(i,1:2592));
%         class = [class;60 score3(1,2)];
%         [YHat4,score4] = predict(Class_90,train_data(i,1:2592));
%         class = [class;90 score4(1,2)];
%         [YHat5,score5] = predict(Class_120,train_data(i,1:2592));
%         class = [class;120 score5(1,2)];
%         [YHat6,score6] = predict(Class_150,train_data(i,1:2592));
%         class = [class;150 score6(1,2)];
%         [YHat7,score7] = predict(Class_180,train_data(i,1:2592));
%         class = [class;180 score7(1,2)];
%         [YHat8,score8] = predict(Class_n30,train_data(i,1:2592));
%         class = [class;-30 score8(1,2)];
%         [YHat9,score9] = predict(Class_n60,train_data(i,1:2592));
%         class = [class;-60 score9(1,2)];
%         [YHat10,score10] = predict(Class_n90,train_data(i,1:2592));
%         class = [class;-90 score10(1,2)];
%         [YHat11,score11] = predict(Class_n120,train_data(i,1:2592));
%         class = [class;-120 score11(1,2)];
%         [YHat12,score12] = predict(Class_n150,train_data(i,1:2592));
%         class = [class;-150 score12(1,2)];
%         [value,idx] = max(class(:,2));
%         label = class(idx,1);
%         label1 = predict(Class_muti,train_data(i,1:2592));
%         
%         if label1 == train_data(i,2593)
%            correct1 = correct1 + 1;
%         end
%         
%         if label == train_data(i,2593)
%            correct = correct + 1;
%         end
%         if (i/size(train_data,1))*100 - precent >= 1
%            precent = (i/size(train_data,1))*100;
%            fprintf('%d%%\n',floor(precent));
%         end  
% end
% 
% y = [y; rate_12 rate_muti];
b = bar(y);
grid on;
set(gca, 'xticklabel', {'Test Set','Training Set'});
legend('12 Class SVM Classifier','One muti-class SVM Classifier');
ylabel('Percentage:%');
grid off;

