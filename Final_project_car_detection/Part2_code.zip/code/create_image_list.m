globals;
ids = {};
for i = 0:7481
    str_i = int2str(i);
    head = strcat('%0','6');
    head = strcat(head,'d');
    idx = sprintf(head, i);
    ids{i+1} = idx;
end
matfile = fullfile(strcat(DATA_DIR,'/train'), 'train_ids.mat');
save(matfile,'ids');



ids = {};
for i = 0:7517
    str_i = int2str(i);
    head = strcat('%0','6');
    head = strcat(head,'d');
    idx = sprintf(head, i);
    ids{i+1} = idx;
end
matfile = fullfile(strcat(DATA_DIR,'/test'), 'test_ids.mat');
save(matfile,'ids');