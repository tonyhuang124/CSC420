globals;
data = getData([], 'train','list');
ids = data.ids;
height = [];
width = [];
length = [];
precent = 0;

for i = 178:size(ids,2)
    image = getData(ids{i}, 'train', 'left');
    %read label file
    fid = fopen(fullfile(DATA_TRAIN_DIR,'label', [ids{i} '.txt']), 'r+');
    label = textscan(fid, '%s %f %f %f %f %f %f %f %f %f %f %f %f %f %f');
    fclose(fid);
    index = find(strcmp(label{1}, 'Car'));
    if ~isempty(index)
        for box = 1:size(index,1)
            heigth = [height label{9}(index(box,1),1)];
            width = [width label{10}(index(box,1),1)];
            length = [length label{11}(index(box,1),1)];
        end
    end
end

avg_heigth = mean(heigth);
avg_width = mean(width);
avg_length = mean(length);