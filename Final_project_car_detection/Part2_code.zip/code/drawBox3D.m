function drawBox3D(ids_i,imdst,ds,Classes)
   globals;
   if ~isempty(ds)
        imdata = getData(ids_i, imdst, 'left');
        im = imdata.im;
        imshow(im); hold on
        for car = 1:size(ds,1)
            viewpoint = viewpoint_prdict(Classes,im,ds(car,:));
            ry = degree2rand(viewpoint);
            [avg_x,avg_y,avg_z,P] = compute_car_addr_3d(ids_i,imdst,ds(car,:));
            [corners,face_idx] = computeBox3D(avg_x,avg_y,avg_z,ry,P);
              % set styles for occlusion and truncation
            trun_style = {'-','--'};
            trc = double(0>0.1)+1;
              % draw projected 3D bounding boxes
            if ~isempty(corners)
               for f=1:4
                 line([corners(1,face_idx(f,:)),corners(1,face_idx(f,1))]+1,...
                       [corners(2,face_idx(f,:)),corners(2,face_idx(f,1))]+1,...
                        'color','g',...
                       'LineWidth',3,'LineStyle',trun_style{trc});
                 line([corners(1,face_idx(f,:)),corners(1,face_idx(f,1))]+1,...
                       [corners(2,face_idx(f,:)),corners(2,face_idx(f,1))]+1,...
                       'color','b','LineWidth',1);
               end
            end
        end
        last_part = strcat(ids_i,'.jpg');
        saveas(1,[Result3D_DIR,last_part]);
        hold off;
        close all;
   end   
end
