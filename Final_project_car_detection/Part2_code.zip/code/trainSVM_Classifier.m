%% Convert -pi to pi TO -180 to 180
data  = getData([], [], 'HOG');
train_precent = 0.8;
test_precent = 1 - train_precent;
index_of_last = size(data.hog,2);
%mode 1 for 12 binary classifiers and mode 0 for muti classifier
mode = 0;



for labels = 1:size(data.hog,1)
    if data.hog(labels,index_of_last) + (pi/2.0) > pi
        data.hog(labels,index_of_last) = floor((((data.hog(labels,index_of_last) + (pi/2.0) - pi)/pi)*180)/30)*30;
        if data.hog(labels,index_of_last) > 0
            data.hog(labels,index_of_last) = data.hog(labels,index_of_last) + 30;
        end
    else
        data.hog(labels,index_of_last) = floor((((data.hog(labels,index_of_last) + (pi/2.0))/pi)*180)/30)*30;
        if data.hog(labels,index_of_last) > 0
            data.hog(labels,index_of_last) = data.hog(labels,index_of_last) + 30;
        end
    end
end


%% muti-classifier data
train_idn =  floor(size(data.hog,1)*train_precent);
train_data = data.hog(1:train_idn ,1:index_of_last);
test_data = data.hog(train_idn:size(data.hog,1) ,1:index_of_last);



if mode == 1
    %% binary-classifier data
    %class = {0,30,60,90,120,150,180,-30,-60,-90,-120,-150}

    %0 and non0 data
    train_data_0 = train_data;
    test_data_0 = test_data;
    for i = 1:size(train_data,1)
        if train_data_0(i,index_of_last) == 0
            train_data_0(i,index_of_last) = 1;
        else
            train_data_0(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_0(i,index_of_last) == 0
            test_data_0(i,index_of_last) = 1;
        else
            test_data_0(i,index_of_last) = 0;
        end
    end

    %30 and non30 data
    train_data_30 = train_data;
    test_data_30 = test_data;
    for i = 1:size(train_data,1)
        if train_data_30(i,index_of_last) == 30
            train_data_30(i,index_of_last) = 1;
        else
            train_data_30(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_30(i,index_of_last) == 30
            test_data_30(i,index_of_last) = 1;
        else
            test_data_30(i,index_of_last) = 0;
        end
    end

    %60 and non60 data
    train_data_60 = train_data;
    test_data_60 = test_data;
    for i = 1:size(train_data,1)
        if train_data_60(i,index_of_last) == 60
            train_data_60(i,index_of_last) = 1;
        else
            train_data_60(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_60(i,index_of_last) == 60
            test_data_60(i,index_of_last) = 1;
        else
            test_data_60(i,index_of_last) = 0;
        end
    end

    %90 and non90 data
    train_data_90 = train_data;
    test_data_90 = test_data;
    for i = 1:size(train_data,1)
        if train_data_90(i,index_of_last) == 90
            train_data_90(i,index_of_last) = 1;
        else
            train_data_90(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_90(i,index_of_last) == 90
            test_data_90(i,index_of_last) = 1;
        else
            test_data_90(i,index_of_last) = 0;
        end
    end

    %120 and non120 data
    train_data_120 = train_data;
    test_data_120 = test_data;
    for i = 1:size(train_data,1)
        if train_data_120(i,index_of_last) == 120
            train_data_120(i,index_of_last) = 1;
        else
            train_data_120(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_120(i,index_of_last) == 120
            test_data_120(i,index_of_last) = 1;
        else
            test_data_120(i,index_of_last) = 0;
        end
    end

    %150 and non150 data
    train_data_150 = train_data;
    test_data_150 = test_data;
    for i = 1:size(train_data,1)
        if train_data_150(i,index_of_last) == 150
            train_data_150(i,index_of_last) = 1;
        else
            train_data_150(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_150(i,index_of_last) == 150
            test_data_150(i,index_of_last) = 1;
        else
            test_data_150(i,index_of_last) = 0;
        end
    end


    %180 and non180 data
    train_data_180 = train_data;
    test_data_180 = test_data;
    for i = 1:size(train_data,1)
        if train_data_180(i,index_of_last) == 180
            train_data_180(i,index_of_last) = 1;
        else
            train_data_180(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_180(i,index_of_last) == 180
            test_data_180(i,index_of_last) = 1;
        else
            test_data_180(i,index_of_last) = 0;
        end
    end


    %-30 and non-30 data
    train_data_n30 = train_data;
    test_data_n30 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n30(i,index_of_last) == -30
            train_data_n30(i,index_of_last) = 1;
        else
            train_data_n30(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n30(i,index_of_last) == -30
            test_data_n30(i,index_of_last) = 1;
        else
            test_data_n30(i,index_of_last) = 0;
        end
    end

    %-60 and non-60 data
    train_data_n60 = train_data;
    test_data_n60 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n60(i,index_of_last) == -60
            train_data_n60(i,index_of_last) = 1;
        else
            train_data_n60(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n60(i,index_of_last) == -60
            test_data_n60(i,index_of_last) = 1;
        else
            test_data_n60(i,index_of_last) = 0;
        end
    end

    %-90 and non-90 data
    train_data_n90 = train_data;
    test_data_n90 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n90(i,index_of_last) == -90
            train_data_n90(i,index_of_last) = 1;
        else
            train_data_n90(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n90(i,index_of_last) == -90
            test_data_n90(i,index_of_last) = 1;
        else
            test_data_n90(i,index_of_last) = 0;
        end
    end

    %120 and non-120 data
    train_data_n120 = train_data;
    test_data_n120 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n120(i,index_of_last) == -120
            train_data_n120(i,index_of_last) = 1;
        else
            train_data_n120(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n120(i,index_of_last) == -120
            test_data_n120(i,index_of_last) = 1;
        else
            test_data_n120(i,index_of_last) = 0;
        end
    end

    %150 and non-150 data
    train_data_n150 = train_data;
    test_data_n150 = test_data;
    for i = 1:size(train_data,1)
        if train_data_n150(i,index_of_last) == -150
            train_data_n150(i,index_of_last) = 1;
        else
            train_data_n150(i,index_of_last) = 0;
        end
    end
    for i = 1:size(test_data,1)
        if test_data_n150(i,index_of_last) == -150
            test_data_n150(i,index_of_last) = 1;
        else
            test_data_n150(i,index_of_last) = 0;
        end
    end



    %% Start Train 12 classifiers

    Class_0 = SVM_binary_classifier(train_data_0);
    Class_0 = Class_0.ClassificationSVM;
    save('Class_0_Classifier','Class_0');
    fprintf('done\n');
    
    Class_30 = SVM_binary_classifier(train_data_30);
    Class_30 = Class_30.ClassificationSVM;
    save('Class_30_Classifier','Class_30');
    fprintf('done\n');   
    
    Class_60 = SVM_binary_classifier(train_data_60);
    Class_60 =Class_60.ClassificationSVM;
    save('Class_60_Classifier','Class_60');
    fprintf('done\n');
    
    Class_90 = SVM_binary_classifier(train_data_90);
    Class_90 =Class_90.ClassificationSVM;
    save('Class_90_Classifier','Class_90');
    fprintf('done\n');
    
    Class_120 = SVM_binary_classifier(train_data_120);
    Class_120 = Class_120.ClassificationSVM;
    save('Class_120_Classifier','Class_120');
    fprintf('done\n');
    
    Class_150 = SVM_binary_classifier(train_data_150);
    Class_150 = Class_150.ClassificationSVM;
    save('Class_150_Classifier','Class_150');
    fprintf('done\n');
    
    Class_180 = SVM_binary_classifier(train_data_180);
    Class_180 = Class_180.ClassificationSVM;
    save('Class_180_Classifier','Class_180');
    fprintf('done\n');
    
    Class_n30 = SVM_binary_classifier(train_data_n30);
    Class_n30 = Class_n30.ClassificationSVM;
    save('Class_n30_Classifier','Class_n30');
    fprintf('done\n');
    
    Class_n60 = SVM_binary_classifier(train_data_n60);
    Class_n60 = Class_n60.ClassificationSVM;
    save('Class_n60_Classifier','Class_n60');
    fprintf('done\n');
    
    Class_n90 = SVM_binary_classifier(train_data_n90);
    Class_n90 = Class_n90.ClassificationSVM;
    save('Class_n90_Classifier','Class_n90');
    fprintf('done\n');
    
    Class_n120 = SVM_binary_classifier(train_data_n120);
    Class_n120 = Class_n120.ClassificationSVM;
    save('Class_n120_Classifier','Class_n120');
    fprintf('done\n');
    
    Class_n150 = SVM_binary_classifier(train_data_n150);
    Class_n150 = Class_n150.ClassificationSVM;
    save('Class_n150_Classifier','Class_n150');
    fprintf('done\n');
    
    
%% train muti-class SVM    
elseif mode == 0
    
    SVM = SVM_Muti_Classifier(train_data);
    Class_muti = SVM.ClassificationSVM;
    save('Class_muti_Classifier','Class_muti');
    fprintf('done\n');
end

