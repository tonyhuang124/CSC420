function [avg_x,avg_y,avg_z,pleft] = compute_car_addr_3d(ids,imdst,ds)


calib = getData(ids, imdst, 'calib');
left_image = getData(ids, imdst, 'left');
left = rgb2gray(left_image.im);
right_image = getData(ids, imdst, 'right');
right = rgb2gray(right_image.im);
f = calib.f;
numerator = f*calib.baseline;
disp = disparity(left,right);
depth = numerator./disp;
pleft = calib.P_left;
[K, R, t]= KRt_from_P(pleft);
Px = K(1,3);
Py = K(2,3);
mid_y = floor((ds(1,2)+ds(1,2)+ds(1,4))/2);
mid_x = floor((ds(1,1)+ds(1,1)+ds(1,3))/2);

avg_z = depth(mid_y,mid_x);
avg_x = (avg_z.*(mid_x - Px))./f;
avg_y = (avg_z.*(mid_y - Py))./f;







